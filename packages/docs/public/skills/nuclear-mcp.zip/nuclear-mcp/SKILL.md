---
name: nuclear-mcp
description: Control Nuclear music player via MCP tools. Use when asked to play music, manage playlists, control playback, search for tracks, or interact with Nuclear. Trigger phrases include "play", "queue", "playlist", "search for music", "pause", "skip", "favorite", "what's playing".
---

# Controlling Nuclear via MCP

Nuclear exposes four MCP tools for controlling the music player. Three are for discovery, one is for execution.

## Tools

| Tool | Input | Purpose |
|------|-------|---------|
| `list_methods` | `{ domain: string }` | List methods in a domain |
| `method_details` | `{ method: string }` | Get a method's params, types, and return type |
| `describe_type` | `{ type: string }` | Get the JSON shape of a data type |
| `call` | `{ method: string, params: object }` | Execute a method |

Method names use `Domain.method` format everywhere: in `method_details` and in `call`.

## Available domains

| Domain | Description |
|--------|-------------|
| Queue | Add, remove, reorder tracks. Navigate the queue. Set repeat/shuffle. |
| Playback | Play, pause, stop, seek. Get playback state. |
| Metadata | Search for music. Fetch artist bios, albums, top tracks. |
| Favorites | Add/remove/check favorite tracks, albums, artists. |
| Playlists | Create, edit, delete, import playlists. Save queue as playlist. |
| Dashboard | Fetch top tracks, top artists, top albums, editorial playlists, new releases. |
| Providers | List and inspect registered music providers. |

## Discovery workflow

Always discover before calling. Don't guess parameter names or types.

1. Call `list_methods` with a domain to see what methods exist.
2. Call `method_details` with `Domain.method` to see parameter names, types, and return type.
3. If a parameter or return type is complex (e.g. `Track`, `SearchParams`), call `describe_type` to see its fields.
4. Call `call` with the method name and a params object.

```
list_methods { domain: "Queue" }
  -> getQueue, getCurrentItem, addToQueue, addNext, clearQueue, ...

method_details { method: "Queue.addToQueue" }
  -> params: [{ name: "tracks", type: "Track[]" }], returns: "void"

describe_type { type: "Track" }
  -> { title: string, artists: ArtistCredit[], source: ProviderRef, ... }

call { method: "Queue.addToQueue", params: { tracks: [...] } }
```

## Parameter passing

- Parameters are a JSON object with named fields, not positional.
- Methods with no parameters: omit `params` or pass `{}`.
- Methods returning `void` produce a `null` result.
- Errors from `call` describe what went wrong (unknown domain, unknown method, missing param).

## Common recipes

### Find a provider first

Most Metadata and Dashboard methods accept an optional `providerId`. Call `Providers.list` to find what's available.

```
call { method: "Providers.list", params: { kind: "metadata" } }
```

The result is an array of `ProviderDescriptor` objects with `id`, `kind`, and `name` fields. Use the `id` value as the `providerId` parameter.

### Search and queue a track

```
call {
  method: "Metadata.search",
  params: {
    params: { query: "Radiohead Creep", types: ["tracks"] },
    providerId: "some-metadata-provider"
  }
}
```

The result is a `SearchResults` object. Take the tracks from `results.tracks` and pass them to the queue:

```
call {
  method: "Queue.addToQueue",
  params: { tracks: [<track objects from search>] }
}
```

To play next instead of appending to the end, use `Queue.addNext`.

### Control playback

```
call { method: "Playback.play" }
call { method: "Playback.pause" }
call { method: "Playback.toggle" }
call { method: "Playback.stop" }
call { method: "Playback.seekTo", params: { seconds: 90 } }
call { method: "Playback.getState" }
```

`getState` returns `{ status, seek, duration }` where `status` is `"playing"`, `"paused"`, or `"stopped"`, and `seek`/`duration` are in seconds.

### Inspect the queue

```
call { method: "Queue.getQueue" }
```

Returns `{ items, currentIndex, repeatMode, shuffleEnabled }`. Each item has an `id`, `track`, and `status`.

Navigate with `Queue.goToNext`, `Queue.goToPrevious`, `Queue.goToIndex`, or `Queue.goToId`.

### Manage playlists

```
call { method: "Playlists.getIndex" }
call { method: "Playlists.getPlaylist", params: { id: "playlist-id" } }
call { method: "Playlists.createPlaylist", params: { name: "My Playlist" } }
call {
  method: "Playlists.addTracks",
  params: { playlistId: "playlist-id", tracks: [...] }
}
call {
  method: "Playlists.removeTracks",
  params: { playlistId: "playlist-id", itemIds: ["item-1", "item-2"] }
}
```

`createPlaylist` returns the new playlist's ID as a string.
`addTracks` returns the created `PlaylistItem[]` objects.
`removeTracks` uses playlist item IDs (from `PlaylistItem.id`), not track IDs.

Save the current queue as a playlist:

```
call { method: "Playlists.saveQueueAsPlaylist", params: { name: "Queue Snapshot" } }
```

### Favorites

```
call { method: "Favorites.getTracks" }
call { method: "Favorites.addTrack", params: { track: <track object> } }
call {
  method: "Favorites.removeTrack",
  params: { source: { provider: "provider-id", id: "track-id" } }
}
call {
  method: "Favorites.isTrackFavorite",
  params: { source: { provider: "provider-id", id: "track-id" } }
}
```

The same pattern applies to albums (`addAlbum`, `removeAlbum`, `isAlbumFavorite`) and artists (`addArtist`, `removeArtist`, `isArtistFavorite`). Album and artist removal uses `ProviderRef` the same way.

### Dashboard/trending content

```
call { method: "Dashboard.fetchTopTracks" }
call { method: "Dashboard.fetchTopArtists" }
call { method: "Dashboard.fetchNewReleases" }
call { method: "Dashboard.fetchEditorialPlaylists" }
```

All Dashboard methods accept an optional `providerId`. Results are `AttributedResult[]`, each containing a `providerId`, `providerName`, and `items` array.

## Reference

For the complete list of methods per domain and all available data types, see [api-reference.md](references/api-reference.md).
