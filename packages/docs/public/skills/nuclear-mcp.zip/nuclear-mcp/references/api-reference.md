# Nuclear MCP API Reference

Full listing of every domain, method, and data type available through Nuclear's MCP tools.

## Queue

Manage the playback queue: add, remove, reorder tracks and control navigation.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getQueue | (none) | Queue | Get the current queue state |
| getCurrentItem | (none) | QueueItem or undefined | Get the currently playing queue item |
| addToQueue | tracks: Track[] | void | Add tracks to the end of the queue |
| addNext | tracks: Track[] | void | Insert tracks immediately after the current item |
| addAt | tracks: Track[], index: number | void | Insert tracks at a specific position |
| removeByIds | ids: string[] | void | Remove items from the queue by their IDs |
| removeByIndices | indices: number[] | void | Remove items from the queue by their indices |
| clearQueue | (none) | void | Remove all items from the queue |
| reorder | fromIndex: number, toIndex: number | void | Move a queue item from one position to another |
| goToNext | (none) | void | Skip to the next item |
| goToPrevious | (none) | void | Go back to the previous item |
| goToIndex | index: number | void | Jump to a specific position in the queue |
| goToId | id: string | void | Jump to a specific queue item by its ID |
| setRepeatMode | mode: "off" or "one" or "all" | void | Set the repeat mode |
| setShuffleEnabled | enabled: boolean | void | Enable or disable shuffle mode |
| updateItemState | id: string, updates: QueueItemStateUpdate | void | Update the loading status of a queue item |

## Playback

Control audio playback state, transport, and seeking.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getState | (none) | PlaybackState | Get the current playback state (status, seek position, duration) |
| play | (none) | void | Start or resume playback |
| pause | (none) | void | Pause playback |
| stop | (none) | void | Stop playback and reset position |
| toggle | (none) | void | Toggle between play and pause |
| seekTo | seconds: number | void | Seek to a position in seconds |

## Metadata

Search for music and fetch artist, album, and track metadata.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| search | params: SearchParams, providerId?: string | SearchResults | Search for artists, albums, tracks, and playlists |
| fetchArtistBio | artistId: string, providerId?: string | ArtistBio | Fetch an artist's biography and tags |
| fetchArtistSocialStats | artistId: string, providerId?: string | ArtistSocialStats | Fetch an artist's social media stats |
| fetchArtistAlbums | artistId: string, providerId?: string | AlbumRef[] | Fetch an artist's album discography |
| fetchArtistTopTracks | artistId: string, providerId?: string | TrackRef[] | Fetch an artist's most popular tracks |
| fetchArtistPlaylists | artistId: string, providerId?: string | PlaylistRef[] | Fetch playlists associated with an artist |
| fetchArtistRelatedArtists | artistId: string, providerId?: string | ArtistRef[] | Fetch artists similar to the given artist |
| fetchAlbumDetails | albumId: string, providerId?: string | Album | Fetch full album details including track listing |

## Favorites

Manage favorite tracks, albums, and artists.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getTracks | (none) | FavoriteEntry<Track>[] | Get all favorite tracks |
| getAlbums | (none) | FavoriteEntry<AlbumRef>[] | Get all favorite albums |
| getArtists | (none) | FavoriteEntry<ArtistRef>[] | Get all favorite artists |
| addTrack | track: Track | void | Add a track to favorites |
| removeTrack | source: ProviderRef | void | Remove a track from favorites by its provider reference |
| isTrackFavorite | source: ProviderRef | boolean | Check if a track is in favorites |
| addAlbum | ref: AlbumRef | void | Add an album to favorites |
| removeAlbum | source: ProviderRef | void | Remove an album from favorites by its provider reference |
| isAlbumFavorite | source: ProviderRef | boolean | Check if an album is in favorites |
| addArtist | ref: ArtistRef | void | Add an artist to favorites |
| removeArtist | source: ProviderRef | void | Remove an artist from favorites by its provider reference |
| isArtistFavorite | source: ProviderRef | boolean | Check if an artist is in favorites |

## Playlists

Create, edit, import, and manage playlists.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getIndex | (none) | PlaylistIndexEntry[] | Get the list of all playlists with summary info |
| getPlaylist | id: string | Playlist or null | Get a playlist by ID with all its items |
| createPlaylist | name: string | string | Create a new empty playlist; returns the playlist ID |
| deletePlaylist | id: string | void | Delete a playlist by ID |
| addTracks | playlistId: string, tracks: Track[] | PlaylistItem[] | Add tracks to a playlist; returns the created playlist items |
| removeTracks | playlistId: string, itemIds: string[] | void | Remove items from a playlist by their item IDs |
| reorderTracks | playlistId: string, from: number, to: number | void | Move a track within a playlist from one position to another |
| importPlaylist | playlist: Playlist | string | Import a full playlist object; returns the new playlist ID |
| saveQueueAsPlaylist | name: string | string | Save the current queue as a new playlist; returns the playlist ID |

## Dashboard

Fetch trending and editorial content from music providers.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| fetchTopTracks | providerId?: string | AttributedResult<Track>[] | Fetch top/trending tracks |
| fetchTopArtists | providerId?: string | AttributedResult<ArtistRef>[] | Fetch top/trending artists |
| fetchTopAlbums | providerId?: string | AttributedResult<AlbumRef>[] | Fetch top/trending albums |
| fetchEditorialPlaylists | providerId?: string | AttributedResult<PlaylistRef>[] | Fetch editorial/curated playlists |
| fetchNewReleases | providerId?: string | AttributedResult<AlbumRef>[] | Fetch new album releases |

## Providers

Query registered music providers (metadata, streaming, dashboard, etc.).

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| list | kind?: string | ProviderDescriptor[] | List all registered providers, optionally filtered by kind |
| get | id: string, kind: string | ProviderDescriptor or undefined | Get a specific provider by ID and kind |

## Types

### ProviderRef

A reference to an entity within a specific provider (e.g. a MusicBrainz artist, a YouTube video).

- provider: string - Provider identifier
- id: string - Entity ID within the provider
- url: string (optional) - URL to the entity on the provider

### ArtistCredit

A credited artist on a track or album, with roles.

- name: string
- roles: string[] - e.g. ["performer", "composer"]
- source: ProviderRef (optional)

### Artwork

A single image at a specific size and purpose.

- url: string
- width: number (optional)
- height: number (optional)
- purpose: "avatar" | "cover" | "background" | "thumbnail" (optional)
- source: ProviderRef (optional)

### ArtworkSet

A collection of artwork images at different sizes and purposes.

- items: Artwork[]

### ArtistRef

A lightweight reference to an artist entity.

- name: string
- disambiguation: string (optional)
- artwork: ArtworkSet (optional)
- source: ProviderRef

### AlbumRef

A lightweight reference to an album.

- title: string
- artists: ArtistRef[] (optional)
- artwork: ArtworkSet (optional)
- source: ProviderRef

### TrackRef

A lightweight reference to a track (used in album track listings).

- title: string
- artists: ArtistRef[]
- artwork: ArtworkSet (optional)
- source: ProviderRef

### LocalFileInfo

Metadata about a local audio file.

- fileUri: string
- fileSize: number (optional)
- format: string (optional)
- bitrateKbps: number (optional)
- sampleRateHz: number (optional)
- channels: number (optional)
- fingerprint: string (optional)
- scannedAtIso: string (optional)

### Stream

A resolved audio stream URL with quality metadata.

- url: string
- protocol: "file" | "http" | "https" | "hls"
- mimeType: string (optional)
- bitrateKbps: number (optional)
- codec: string (optional)
- container: string (optional)
- qualityLabel: string (optional)
- durationMs: number (optional)
- contentLengthBytes: number (optional)
- source: ProviderRef

### StreamCandidate

A potential stream source for a track, possibly with a resolved stream.

- id: string
- title: string
- durationMs: number (optional)
- thumbnail: string (optional)
- stream: Stream (optional)
- lastResolvedAtIso: string (optional)
- failed: boolean
- source: ProviderRef

### Track

A full track with metadata, artwork, and optional streaming info.

- title: string
- artists: ArtistCredit[]
- album: AlbumRef (optional)
- durationMs: number (optional)
- trackNumber: number (optional)
- disc: string (optional)
- artwork: ArtworkSet (optional)
- tags: string[] (optional)
- source: ProviderRef
- localFile: LocalFileInfo (optional)
- streamCandidates: StreamCandidate[] (optional)

### QueueItem

A track in the playback queue with its loading status.

- id: string
- track: Track
- status: "idle" | "loading" | "success" | "error"
- error: string (optional)
- addedAtIso: string

### Queue

The playback queue state.

- items: QueueItem[]
- currentIndex: number
- repeatMode: "off" | "all" | "one"
- shuffleEnabled: boolean

### PlaylistRef

A lightweight reference to a playlist.

- id: string
- name: string
- artwork: ArtworkSet (optional)
- source: ProviderRef

### PlaylistItem

A track within a playlist.

- id: string
- track: Track
- note: string (optional)
- addedAtIso: string

### Playlist

A full playlist with metadata and items.

- id: string
- name: string
- description: string (optional)
- artwork: ArtworkSet (optional)
- tags: string[] (optional)
- createdAtIso: string
- lastModifiedIso: string
- origin: ProviderRef (optional)
- isReadOnly: boolean
- parentId: string (optional)
- items: PlaylistItem[]

### PlaylistIndexEntry

Summary info for a playlist in the index.

- id: string
- name: string
- createdAtIso: string
- lastModifiedIso: string
- isReadOnly: boolean
- artwork: ArtworkSet (optional)
- itemCount: number
- totalDurationMs: number

### SearchParams

Parameters for a music search query.

- query: string
- types: ("artists" | "albums" | "tracks" | "playlists")[] (optional) - Categories to search
- limit: number (optional)

### SearchResults

Results from a music search, grouped by category.

- artists: ArtistRef[] (optional)
- albums: AlbumRef[] (optional)
- tracks: Track[] (optional)
- playlists: PlaylistRef[] (optional)

### Album

A full album with track listing and metadata.

- title: string
- artists: ArtistCredit[]
- tracks: TrackRef[] (optional)
- releaseDate: ReleaseDate (optional) - Release date with precision
- genres: string[] (optional)
- artwork: ArtworkSet (optional)
- source: ProviderRef

### ReleaseDate

A date with precision indicator.

- precision: "year" | "month" | "day"
- dateIso: string

### ArtistBio

An artist's biography, tags, and tour status.

- name: string
- disambiguation: string (optional)
- bio: string (optional)
- onTour: boolean (optional)
- artwork: ArtworkSet (optional)
- tags: string[] (optional)
- source: ProviderRef

### ArtistSocialStats

An artist's social media and platform statistics.

- name: string
- artwork: ArtworkSet (optional)
- city: string (optional)
- country: string (optional)
- followersCount: number (optional)
- followingsCount: number (optional)
- trackCount: number (optional)
- playlistCount: number (optional)
- source: ProviderRef

### PlaybackState

Current audio playback state.

- status: "playing" | "paused" | "stopped"
- seek: number - Current position in seconds
- duration: number - Total duration in seconds

### FavoriteEntry

A favorited item with timestamp. The ref field contains the actual entity (Track, AlbumRef, or ArtistRef).

- ref: Track | AlbumRef | ArtistRef - The favorited entity
- addedAtIso: string

### AttributedResult

A batch of results from a specific provider.

- providerId: string
- metadataProviderId: string (optional)
- providerName: string
- items: any[] - Array of result items (Track, ArtistRef, AlbumRef, or PlaylistRef depending on the endpoint)

### ProviderDescriptor

Describes a registered provider (metadata, streaming, dashboard, etc.).

- id: string
- kind: string - Provider kind: metadata, streaming, lyrics, dashboard, etc.
- name: string
- pluginId: string (optional)

### QueueItemStateUpdate

Partial update for a queue item status.

- status: "idle" | "loading" | "success" | "error" (optional)
- error: string (optional)

### StreamResolutionResult

Result of resolving stream candidates for a track. Either succeeds with candidates or fails with an error.

- success: boolean
- candidates: StreamCandidate[] (optional) - Present when success is true
- error: string (optional) - Present when success is false
