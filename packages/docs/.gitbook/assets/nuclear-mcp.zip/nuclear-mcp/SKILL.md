---
name: nuclear-mcp
description: Control the Nuclear music player through MCP tools. Use this skill when a user tells you to play music, manage playlists, control playback, search for tracks, or interact with Nuclear. The trigger phrases include "play", "queue", "playlist", "search for music", "pause", "skip", "favorite", "what's playing".
---

# Control Nuclear through MCP

Nuclear exposes four MCP tools that control the music player. Three tools are for discovery. One tool is for execution.

## Tools

| Tool | Input | Purpose |
|------|-------|---------|
| `list_methods` | `{ domain: string }` | List the methods in a domain |
| `method_details` | `{ method: string }` | Get the parameters, types, and return type of a method |
| `describe_type` | `{ type: string }` | Get the JSON shape of a data type |
| `call` | `{ method: string, params: object }` | Execute a method |

Use the `Domain.method` format for method names in all tools: in `method_details` and in `call`.

## Available domains

| Domain | Description |
|--------|-------------|
| Queue | Add, remove, and reorder tracks. Navigate the queue. Set the repeat mode and the shuffle mode. |
| Playback | Play, pause, stop, and seek. Get the playback state. |
| Metadata | Search for music. Fetch artist bios, albums, and top tracks. |
| Favorites | Add, remove, and check favorite tracks, albums, and artists. |
| Playlists | Create, edit, delete, and import playlists. Save the queue as a playlist. Create, rename, and delete folders. Move playlists into folders and out of folders. |
| Dashboard | Fetch top tracks, top artists, top albums, editorial playlists, and new releases. |
| Providers | List and inspect the registered music providers. |
| Views | Add your own pages to the left sidebar. Write each page as TSX source. |

## Discovery workflow

Always discover a method before you call it. Do not guess parameter names or types.

1. Call `list_methods` with a domain to list its methods.
2. Call `method_details` with `Domain.method` to get the parameter names, the types, and the return type.
3. If a parameter type or a return type is complex (for example, `Track` or `SearchParams`), call `describe_type` to get its fields.
4. Call `call` with the method name and a `params` object.

```
list_methods { domain: "Queue" }
  -> getQueue, getCurrentItem, addToQueue, addNext, clearQueue, ...

method_details { method: "Queue.addToQueue" }
  -> params: [{ name: "tracks", type: "Track[]" }], returns: "void"

describe_type { type: "Track" }
  -> { title: string, artists: ArtistCredit[], source: ProviderRef, ... }

call { method: "Queue.addToQueue", params: { tracks: [...] } }
```

## Parameter passing

- Pass parameters as a JSON object with named fields, not as positional arguments.
- If a method has no parameters, omit `params` or pass `{}`.
- If a method returns `void`, `call` returns `null`.
- If `call` fails, you get an error that describes the cause: unknown domain, unknown method, or missing parameter.

## Common recipes

### Find a provider first

Most Metadata methods and Dashboard methods accept an optional `providerId` parameter. To find the available providers, call `Providers.list`.

```
call { method: "Providers.list", params: { kind: "metadata" } }
```

The result is an array of `ProviderDescriptor` objects with `id`, `kind`, and `name` fields. Pass the `id` value as the `providerId` parameter.

### Search for a track and add it to the queue

```
call {
  method: "Metadata.search",
  params: {
    params: { query: "Radiohead Creep", types: ["tracks"] },
    providerId: "some-metadata-provider"
  }
}
```

The result is a `SearchResults` object. Pass the tracks from `results.tracks` to `Queue.addToQueue`:

```
call {
  method: "Queue.addToQueue",
  params: { tracks: [<track objects from search>] }
}
```

To insert the tracks after the current item, and not append them to the end of the queue, use `Queue.addNext`.

### Control playback

```
call { method: "Playback.play" }
call { method: "Playback.pause" }
call { method: "Playback.toggle" }
call { method: "Playback.stop" }
call { method: "Playback.seekTo", params: { seconds: 90 } }
call { method: "Playback.getState" }
```

`getState` returns `{ status, seek, duration }`. The value of `status` is `"playing"`, `"paused"`, or `"stopped"`. The unit of `seek` and `duration` is seconds.

### Inspect the queue

```
call { method: "Queue.getQueue" }
```

`Queue.getQueue` returns `{ items, currentIndex, repeatMode, shuffleEnabled }`. Each item has an `id`, a `track`, and a `status`.

To navigate the queue, call `Queue.goToNext`, `Queue.goToPrevious`, `Queue.goToIndex`, or `Queue.goToId`.

### Manage playlists

```
call { method: "Playlists.getIndex" }
call { method: "Playlists.getPlaylist", params: { id: "playlist-id" } }
call { method: "Playlists.createPlaylist", params: { name: "My Playlist" } }
call {
  method: "Playlists.addTracks",
  params: { playlistId: "playlist-id", tracks: [...] }
}
call {
  method: "Playlists.removeTracks",
  params: { playlistId: "playlist-id", itemIds: ["item-1", "item-2"] }
}
```

`createPlaylist` returns the ID of the new playlist as a string.
`addTracks` returns the created `PlaylistItem[]` objects.
`removeTracks` takes playlist item IDs (from `PlaylistItem.id`), not track IDs.

To save the current queue as a playlist, call `Playlists.saveQueueAsPlaylist`:

```
call { method: "Playlists.saveQueueAsPlaylist", params: { name: "Queue Snapshot" } }
```

### Organize playlists into folders

```
call { method: "Playlists.getIndexTree" }
call { method: "Playlists.createFolder", params: { name: "Workouts" } }
call {
  method: "Playlists.movePlaylistToFolder",
  params: { playlistId: "playlist-id", folderId: "folder-id" }
}
call {
  method: "Playlists.saveQueueAsPlaylist",
  params: { name: "Cardio", folderId: "folder-id" }
}
```

`getIndexTree` returns the top level of the index in display order. Each item has `kind: "playlist"` or `kind: "folder"`.
A folder contains its playlists in the `playlists` field.
`getIndex` returns a flat list of all playlists. The list includes the playlists in folders.
`createFolder` returns the ID of the new folder. A folder cannot contain other folders.
To move a playlist to the end of the top level, call `movePlaylistToFolder` without `folderId`.
`deleteFolder` does not delete the playlists in the folder. The playlists move to the position of the folder.
If a folder ID or a playlist ID does not exist, the folder methods return an error.

### Favorites

```
call { method: "Favorites.getTracks" }
call { method: "Favorites.addTrack", params: { track: <track object> } }
call {
  method: "Favorites.removeTrack",
  params: { source: { provider: "provider-id", id: "track-id" } }
}
call {
  method: "Favorites.isTrackFavorite",
  params: { source: { provider: "provider-id", id: "track-id" } }
}
```

Use the same pattern for albums (`addAlbum`, `removeAlbum`, `isAlbumFavorite`) and for artists (`addArtist`, `removeArtist`, `isArtistFavorite`). To remove an album or an artist, pass a `ProviderRef`, as for a track.

### Dashboard and trending content

```
call { method: "Dashboard.fetchTopTracks" }
call { method: "Dashboard.fetchTopArtists" }
call { method: "Dashboard.fetchNewReleases" }
call { method: "Dashboard.fetchEditorialPlaylists" }
```

All Dashboard methods accept an optional `providerId` parameter. They return `AttributedResult[]`. Each result contains a `providerId`, a `providerName`, and an `items` array.

### Add a page to the sidebar

```
call {
  method: "Views.register",
  params: {
    view: {
      id: "hello",
      title: "Hello",
      icon: "Smile",
      source: "export default function Hello() { return <h1 className=\"text-2xl\">Hello</h1>; }\nexport function Greeting({ params }) { return <p>Hello, {params.name}</p>; }",
      routes: [
        { path: "/" },
        { path: "/greet/$name", export: "Greeting" }
      ]
    }
  }
}
```

- `source` is one TSX module. For each route, Nuclear renders the named `export`. If `export` is not set, Nuclear renders the default export.
- Nuclear passes `{ params, api }` to each component. The `$name` segments in a path become params. If more than one route matches, Nuclear uses the first match.
- The module can import only `react`, `@nuclearplayer/ui`, and `@nuclearplayer/plugin-sdk`. You can use all Tailwind classes. This includes the classes that the player itself does not use.
- `icon` is the name of a Lucide icon.
- The view opens at `/plugin/bridge/<viewId>`. To open the view, call `Navigation.navigate`.
- To replace a view, register it again with the same `id`. If the view is open, Nuclear renders the new version.
- To remove a view, call `Views.unregister { id }`. If the view is open, Nuclear opens the dashboard.
- Nuclear does not persist views after a restart.

## Reference

For the full list of methods in each domain and all available data types, refer to [api-reference.md](references/api-reference.md).
