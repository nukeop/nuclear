# Nuclear MCP API Reference

This file lists every domain, method, and data type that Nuclear exposes through its MCP tools.

## Queue

Manage the playback queue: add, remove, and reorder tracks, and navigate the queue.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getQueue | (none) | Queue | Get the current queue state |
| getCurrentItem | (none) | QueueItem or undefined | Get the current queue item, which is the item that plays at this time |
| addToQueue | tracks: Track[] | void | Append tracks to the end of the queue |
| addNext | tracks: Track[] | void | Insert tracks immediately after the current item |
| addAt | tracks: Track[], index: number | void | Insert tracks at a specified index |
| removeByIds | ids: string[] | void | Remove items from the queue by their IDs |
| removeByIndices | indices: number[] | void | Remove items from the queue by their indices |
| clearQueue | (none) | void | Remove all items from the queue |
| reorder | fromIndex: number, toIndex: number | void | Move a queue item from one index to a different index |
| goToNext | (none) | void | Skip to the next item |
| goToPrevious | (none) | void | Go back to the previous item |
| goToIndex | index: number | void | Go to a specified index in the queue |
| goToId | id: string | void | Go to a queue item by its ID |
| setRepeatMode | mode: "off" or "one" or "all" | void | Set the repeat mode |
| setShuffleEnabled | enabled: boolean | void | Enable or disable shuffle mode |
| updateItemState | id: string, updates: QueueItemStateUpdate | void | Update the loading status of a queue item |

## Playback

Control the playback state, transport, and seeking.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getState | (none) | PlaybackState | Get the current playback state (status, seek position, duration) |
| play | (none) | void | Start or resume playback |
| pause | (none) | void | Pause playback |
| stop | (none) | void | Stop playback and reset the position |
| toggle | (none) | void | Toggle between play and pause |
| seekTo | seconds: number | void | Seek to a position, in seconds |

## Metadata

Search for music. Fetch artist, album, and track metadata.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| search | params: SearchParams, providerId?: string | SearchResults | Search for artists, albums, tracks, and playlists |
| fetchArtistBio | artistId: string, providerId?: string | ArtistBio | Fetch the biography and tags of an artist |
| fetchArtistSocialStats | artistId: string, providerId?: string | ArtistSocialStats | Fetch the social media stats of an artist |
| fetchArtistAlbums | artistId: string, providerId?: string | AlbumRef[] | Fetch the album discography of an artist |
| fetchArtistTopTracks | artistId: string, providerId?: string | TrackRef[] | Fetch the top tracks of an artist |
| fetchArtistPlaylists | artistId: string, providerId?: string | PlaylistRef[] | Fetch the playlists related to an artist |
| fetchArtistRelatedArtists | artistId: string, providerId?: string | ArtistRef[] | Fetch the artists related to the given artist |
| fetchAlbumDetails | albumId: string, providerId?: string | Album | Fetch the full album entity, with its track listing |

## Favorites

Manage favorite tracks, albums, and artists.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getTracks | (none) | FavoriteEntry<Track>[] | Get all favorite tracks |
| getAlbums | (none) | FavoriteEntry<AlbumRef>[] | Get all favorite albums |
| getArtists | (none) | FavoriteEntry<ArtistRef>[] | Get all favorite artists |
| addTrack | track: Track | void | Add a track to favorites |
| removeTrack | source: ProviderRef | void | Remove a track from favorites by its provider reference |
| isTrackFavorite | source: ProviderRef | boolean | Check if a track is in favorites |
| addAlbum | ref: AlbumRef | void | Add an album to favorites |
| removeAlbum | source: ProviderRef | void | Remove an album from favorites by its provider reference |
| isAlbumFavorite | source: ProviderRef | boolean | Check if an album is in favorites |
| addArtist | ref: ArtistRef | void | Add an artist to favorites |
| removeArtist | source: ProviderRef | void | Remove an artist from favorites by its provider reference |
| isArtistFavorite | source: ProviderRef | boolean | Check if an artist is in favorites |

## Playlists

Create, edit, import, and manage playlists and folders. A folder can contain only playlists. A folder cannot contain other folders.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| getIndex | (none) | PlaylistIndexEntry[] | Get a flat list of all playlists, with summary fields. The list includes the playlists in folders |
| getIndexTree | (none) | (PlaylistIndexEntry or PlaylistFolder)[] | Get the playlists and folders in display order. Each folder contains its playlists |
| getPlaylist | id: string | Playlist or null | Get a playlist with all its items by ID |
| createPlaylist | name: string | string | Create a new empty playlist. Returns the playlist ID |
| deletePlaylist | id: string | void | Delete a playlist by ID |
| addTracks | playlistId: string, tracks: Track[] | PlaylistItem[] | Add tracks to a playlist. Returns the created playlist items |
| removeTracks | playlistId: string, itemIds: string[] | void | Remove items from a playlist by their item IDs |
| reorderTracks | playlistId: string, from: number, to: number | void | Move a track in a playlist from one index to a different index |
| importPlaylist | playlist: Playlist | string | Import a full playlist object. Returns the new playlist ID |
| saveQueueAsPlaylist | name: string, folderId?: string | string | Save the current queue as a new playlist, optionally in a folder. Returns the playlist ID |
| createFolder | name: string | string | Create an empty folder at the end of the top level. Returns the folder ID |
| renameFolder | id: string, name: string | void | Rename a folder |
| deleteFolder | id: string | void | Delete a folder. The playlists in the folder are not deleted. They move to the position of the folder |
| movePlaylistToFolder | playlistId: string, folderId?: string | void | Move a playlist to the end of a folder. If you do not pass a folder ID, the playlist moves to the end of the top level |

## Dashboard

Fetch trending and editorial content from music providers.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| fetchTopTracks | providerId?: string | AttributedResult<Track>[] | Fetch top or trending tracks |
| fetchTopArtists | providerId?: string | AttributedResult<ArtistRef>[] | Fetch top or trending artists |
| fetchTopAlbums | providerId?: string | AttributedResult<AlbumRef>[] | Fetch top or trending albums |
| fetchEditorialPlaylists | providerId?: string | AttributedResult<PlaylistRef>[] | Fetch editorial or curated playlists |
| fetchNewReleases | providerId?: string | AttributedResult<AlbumRef>[] | Fetch new album releases |

## Providers

Query the registered music providers (for example, metadata, streaming, and dashboard providers).

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| list | kind?: string | ProviderDescriptor[] | List all registered providers, optionally filtered by kind |
| get | id: string, kind: string | ProviderDescriptor or undefined | Get a provider by ID and kind |

## Views

Register views in the left sidebar of the player. Views open at `/plugin/bridge/<viewId>`. Nuclear does not persist views after a restart.

| Method | Params | Returns | Description |
|--------|--------|---------|-------------|
| register | view: RawViewDefinition | void | Add a view to the left sidebar. To replace a view, call register again with the same id |
| unregister | id: string | void | Remove the view with this id. If the view is open, Nuclear opens the dashboard |

## Types

### ProviderRef

A reference to an entity in a specified provider (for example, a MusicBrainz artist or a YouTube video).

- provider: string - The provider ID
- id: string - The entity ID in the provider
- url: string (optional) - The URL of the entity on the provider

### ArtistCredit

A credited artist on a track or an album, with roles.

- name: string
- roles: string[] - For example, ["performer", "composer"]
- source: ProviderRef (optional)

### Artwork

One image with a specified size and purpose.

- url: string
- width: number (optional)
- height: number (optional)
- purpose: "avatar" | "cover" | "background" | "thumbnail" (optional)
- source: ProviderRef (optional)

### ArtworkSet

A collection of artwork images with different sizes and purposes.

- items: Artwork[]

### ArtistRef

A lightweight reference to an artist entity.

- name: string
- disambiguation: string (optional)
- artwork: ArtworkSet (optional)
- source: ProviderRef

### AlbumRef

A lightweight reference to an album.

- title: string
- artists: ArtistRef[] (optional)
- artwork: ArtworkSet (optional)
- source: ProviderRef

### TrackRef

A lightweight reference to a track. Nuclear uses this type in album track listings.

- title: string
- artists: ArtistRef[]
- artwork: ArtworkSet (optional)
- source: ProviderRef

### LocalFileInfo

Metadata about a local audio file.

- fileUri: string
- fileSize: number (optional)
- format: string (optional)
- bitrateKbps: number (optional)
- sampleRateHz: number (optional)
- channels: number (optional)
- fingerprint: string (optional)
- scannedAtIso: string (optional)

### Stream

A resolved audio stream URL, with quality metadata.

- url: string
- protocol: "file" | "http" | "https" | "hls"
- mimeType: string (optional)
- bitrateKbps: number (optional)
- codec: string (optional)
- container: string (optional)
- qualityLabel: string (optional)
- durationMs: number (optional)
- contentLengthBytes: number (optional)
- source: ProviderRef

### StreamCandidate

A candidate stream source for a track, optionally with a resolved stream.

- id: string
- title: string
- durationMs: number (optional)
- thumbnail: string (optional)
- stream: Stream (optional)
- lastResolvedAtIso: string (optional)
- failed: boolean
- source: ProviderRef

### Track

A full track with metadata, artwork, and optional streaming information.

- title: string
- artists: ArtistCredit[]
- album: AlbumRef (optional)
- durationMs: number (optional)
- trackNumber: number (optional)
- disc: string (optional)
- artwork: ArtworkSet (optional)
- tags: string[] (optional)
- source: ProviderRef
- localFile: LocalFileInfo (optional)
- streamCandidates: StreamCandidate[] (optional)

### QueueItem

A track in the playback queue, with its loading status.

- id: string
- track: Track
- status: "idle" | "loading" | "success" | "error"
- error: string (optional)
- addedAtIso: string

### Queue

The playback queue state.

- items: QueueItem[]
- currentIndex: number
- repeatMode: "off" | "all" | "one"
- shuffleEnabled: boolean

### PlaylistRef

A lightweight reference to a playlist.

- id: string
- name: string
- artwork: ArtworkSet (optional)
- source: ProviderRef

### PlaylistItem

A track in a playlist.

- id: string
- track: Track
- note: string (optional)
- addedAtIso: string

### Playlist

A full playlist with metadata and items.

- id: string
- name: string
- description: string (optional)
- artwork: ArtworkSet (optional)
- tags: string[] (optional)
- createdAtIso: string
- lastModifiedIso: string
- origin: ProviderRef (optional)
- isReadOnly: boolean
- parentId: string (optional)
- items: PlaylistItem[]

### PlaylistIndexEntry

Summary fields for a playlist in the index.

- kind: "playlist"
- id: string
- name: string
- createdAtIso: string
- lastModifiedIso: string
- isReadOnly: boolean
- artwork: ArtworkSet (optional)
- itemCount: number
- totalDurationMs: number
- thumbnails: string[] - Artwork URLs for the playlist card

### PlaylistFolder

A folder of playlists. A folder cannot contain other folders.

- kind: "folder"
- id: string
- name: string
- playlists: PlaylistIndexEntry[] - The playlists in the folder, in display order

### SearchParams

The parameters of a music search query.

- query: string
- types: ("artists" | "albums" | "tracks" | "playlists")[] (optional) - The categories to search
- limit: number (optional)

### SearchResults

The results of a music search, grouped by category.

- artists: ArtistRef[] (optional)
- albums: AlbumRef[] (optional)
- tracks: Track[] (optional)
- playlists: PlaylistRef[] (optional)

### Album

A full album with its track listing and metadata.

- title: string
- artists: ArtistCredit[]
- tracks: TrackRef[] (optional)
- releaseDate: ReleaseDate (optional) - The release date, with its precision
- genres: string[] (optional)
- artwork: ArtworkSet (optional)
- source: ProviderRef

### ReleaseDate

A date with a precision indicator.

- precision: "year" | "month" | "day"
- dateIso: string

### ArtistBio

The biography, tags, and tour status of an artist.

- name: string
- disambiguation: string (optional)
- bio: string (optional)
- onTour: boolean (optional)
- artwork: ArtworkSet (optional)
- tags: string[] (optional)
- source: ProviderRef

### ArtistSocialStats

The social media stats and platform stats of an artist.

- name: string
- artwork: ArtworkSet (optional)
- city: string (optional)
- country: string (optional)
- followersCount: number (optional)
- followingsCount: number (optional)
- trackCount: number (optional)
- playlistCount: number (optional)
- source: ProviderRef

### PlaybackState

The current audio playback state.

- status: "playing" | "paused" | "stopped"
- seek: number - The current position, in seconds
- duration: number - The total duration, in seconds

### FavoriteEntry

A favorite entity with a timestamp. The ref field contains the entity (Track, AlbumRef, or ArtistRef).

- ref: Track | AlbumRef | ArtistRef - The favorite entity
- addedAtIso: string

### AttributedResult

A batch of results from a specified provider.

- providerId: string
- metadataProviderId: string (optional)
- providerName: string
- items: any[] - An array of result items. The item type (Track, ArtistRef, AlbumRef, or PlaylistRef) depends on the endpoint

### ProviderDescriptor

Metadata about a registered provider (for example, a metadata, streaming, or dashboard provider).

- id: string
- kind: string - The provider kind, for example metadata, streaming, lyrics, or dashboard
- name: string
- pluginId: string (optional)

### QueueItemStateUpdate

A partial update to the status of a queue item.

- status: "idle" | "loading" | "success" | "error" (optional)
- error: string (optional)

### StreamResolutionResult

The result of stream resolution for a track. On success, it contains candidates. On failure, it contains an error.

- success: boolean
- candidates: StreamCandidate[] (optional) - Set when success is true
- error: string (optional) - Set when success is false

### RawViewDefinition

A view for the left sidebar, written as TSX source.

- id: string
- title: string
- icon: string - The name of a Lucide icon
- source: string - One TSX module. It can import only react, @nuclearplayer/ui, and @nuclearplayer/plugin-sdk. Nuclear passes { params, api } to each component
- routes: { path: string, export?: string }[] - Paths, for example "/" or "/episode/$episodeId". The `$name` segments become params. If more than one route matches, Nuclear uses the first match. For each route, Nuclear renders the named export, or the default export
